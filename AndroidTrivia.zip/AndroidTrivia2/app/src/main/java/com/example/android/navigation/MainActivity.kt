/*
 * Copyright 2018, The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.example.android.navigation

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.databinding.DataBindingUtil
import androidx.navigation.findNavController
import androidx.navigation.ui.NavigationUI
import com.example.android.navigation.databinding.ActivityMainBinding
import androidx.drawerlayout.widget.DrawerLayout


class MainActivity : AppCompatActivity() {
    //Naga - Drawelayout handle to display the Navigation Drawer
    private lateinit var drawerLayout: DrawerLayout
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        @Suppress("UNUSED_VARIABLE")
        val binding = DataBindingUtil.setContentView<ActivityMainBinding>(this, R.layout.activity_main)

        //add code to find the navigation controller object:
        val navController = this.findNavController(R.id.myNavHostFragment)

        // add code to link the navigation controller to the app bar:
        //NavigationUI.setupActionBarWithNavController(this,navController)

        //Naga- Modifying the above commented ActionBar display to include DrawerLayout
        drawerLayout = binding.drawerLayout
        NavigationUI.setupActionBarWithNavController(this, navController, drawerLayout)

        //to display Navigation drawer
        NavigationUI.setupWithNavController(binding.navView, navController)

    }

    //override the onSupportNavigateUp() method to call navigateUp() in the navigation controller:
    override fun onSupportNavigateUp(): Boolean {
        val navController = this.findNavController(R.id.myNavHostFragment)

//        return navController.navigateUp()

         //Naga- modifying the above return value to include Drawer Layout
        return NavigationUI.navigateUp(navController, drawerLayout)

    }
    // TODO (01) Create the new TitleFragment
    // Select File->New->Fragment->Fragment (Blank)

    // TODO (02) Clean up the new TitleFragment
    // In our new TitleFragment

    // TODO (03) Use DataBindingUtil.inflate to inflate and return the titleFragment in onCreateView
    // In our new TitleFragment
    // R.layout.fragment_title
}
