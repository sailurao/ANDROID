package com.example.aboutme

import android.content.Context
import android.opengl.Visibility
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import androidx.databinding.DataBindingUtil
import androidx.databinding.adapters.TextViewBindingAdapter.setText
import com.example.aboutme.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var myName:MyName= MyName("Naga Amam")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       // setContentView(R.layout.activity_main)
        binding = DataBindingUtil.setContentView(this,R.layout.activity_main)
        //var hBtn:Button = findViewById(R.id.done_button)
        //hBtn.setOnClickListener { SetNickName(it) }
        binding.doneButton.setOnClickListener { SetNickName(it) }

        binding.myName = myName
        //var hNickText = findViewById<TextView>(R.id.nickname_text)
        //hNickText.setOnClickListener {  ShowNameEntry(it)}
        binding.nicknameText.setOnClickListener{ShowNameEntry(it)}

    }

    private fun SetNickName(vw: View ){

        vw.visibility= View.GONE
        //var hNickEdit:TextView = findViewById(R.id.nickname_edit)
        //hNickEdit.visibility = View.GONE
        binding.apply {
            nicknameEdit.visibility = View.GONE
//        var hNickText = findViewById<TextView>(R.id.nickname_text)
//        hNickText.visibility =View.VISIBLE
            nicknameText.visibility = View.VISIBLE
            // binding.nicknameText.text = binding.nicknameEdit.text
            myName?.nickname = binding.nicknameEdit.text.toString()
            invalidateAll()
        }

        val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(vw.windowToken, 0)
    }

    private fun ShowNameEntry(vw : View){
        vw.visibility= View.GONE
        var str: String=""
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        binding.apply {
            //var hNickEdit: TextView = findViewById(R.id.nickname_edit)
            //hNickEdit.visibility = View.VISIBLE
            nicknameEdit.visibility=View.VISIBLE
            //var hBtn = findViewById<Button>(R.id.done_button)
            //hBtn.visibility = View.VISIBLE
            doneButton.visibility=View.VISIBLE

           nicknameEdit.setText(str)

            //hNickEdit.text = ""
            // Set the focus to the edit text.
            //hNickEdit.requestFocus()
            nicknameEdit.requestFocus()
            imm.showSoftInput(nicknameEdit, 0)
            invalidateAll()
        }
// Show the keyboard.


    }

}