package com.example.aboutme

data class MyName(val name:String="", var nickname:String="")