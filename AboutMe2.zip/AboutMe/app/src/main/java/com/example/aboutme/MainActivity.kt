package com.example.aboutme

import android.content.Context
import android.opengl.Visibility
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.TextView
import com.example.aboutme.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        var hBtn:Button = findViewById(R.id.done_button)
        hBtn.setOnClickListener { SetNickName(it) }
        var hNickText = findViewById<TextView>(R.id.nickname_text)
        hNickText.setOnClickListener {  ShowNameEntry(it)}
    }

    private fun SetNickName(vw: View ){

        vw.visibility= View.GONE
        var hNickEdit:TextView = findViewById(R.id.nickname_edit)
        hNickEdit.visibility = View.GONE
        var hNickText = findViewById<TextView>(R.id.nickname_text)
        hNickText.visibility =View.VISIBLE
        hNickText.text = hNickEdit.text
        val inputMethodManager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        inputMethodManager.hideSoftInputFromWindow(vw.windowToken, 0)
    }

    private fun ShowNameEntry(vw : View){
        vw.visibility= View.GONE
        var hNickEdit:TextView = findViewById(R.id.nickname_edit)
        hNickEdit.visibility = View.VISIBLE
        var hBtn = findViewById<Button>(R.id.done_button)
        hBtn.visibility =View.VISIBLE
        hNickEdit.text = ""
        // Set the focus to the edit text.
        hNickEdit.requestFocus()
// Show the keyboard.
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.showSoftInput(hNickEdit, 0)
    }

}